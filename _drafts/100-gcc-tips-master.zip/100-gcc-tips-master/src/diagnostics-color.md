# 打印彩色诊断信息

## 技巧

这是gcc-4.9新增的功能，可以通过定义环境变量`GCC_COLORS`来彩色打印诊断信息。

也可以使用选项`-fdiagnostics-color`来设定。

详情参见[gcc手册](https://gcc.gnu.org/onlinedocs/gcc/Language-Independent-Options.html#Language-Independent-Options)

## 贡献者

xmj

